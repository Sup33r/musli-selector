// musli-selector.js
function updateStatusBar(percentage) {
    document.getElementById('status-bar').style.width = percentage + '%';
}
